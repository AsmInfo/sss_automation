<?php

namespace App\Filament\Resources\ComponentsResource\Pages;

use App\Filament\Resources\ComponentsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateComponents extends CreateRecord
{
    protected static string $resource = ComponentsResource::class;
    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
